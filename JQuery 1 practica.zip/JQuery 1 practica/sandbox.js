//Ejercicio1

$(document).ready(function(){

//1parte
var parte1 = $("div").find(".module");
console.log(parte1.length);

//2parte
var prueba = $("#myList").find("li").first().next().next();
var prueba2 = $("#myList li:odd").first().next();      //el más rentable si conoces la cantidad de elementos que contiene el ul especifico
var prueba3 = $("#myList").find("li").last().prev().prev().prev().prev();
console.log(prueba.text());
console.log(prueba2.text());
console.log(prueba3.text());

//3parte
var atributo = $("input").attr("name");
var pruebalabel = $("label[for="+atributo+"]");
console.log(pruebalabel.text());

//4parte
var oculto = $("body").find(":hidden");
console.log(oculto.length);

//5parte
var imagenes = $("img[alt]");
console.log(imagenes.length);

//6parte
var elementos = $("tbody").find("tr:odd");
console.log(elementos);

//Ejercicio2

//parte1
var contenido = $("img[alt]");
for(contador = 0; contador < contenido.length; contador++)
{
console.log($(contenido[contador]).attr("alt"));
}

//parte2
$("input").closest("form").addClass("formulario");

//parte3
$("#myList").find(".current").removeClass("current").next().addClass("current");

//parte4
var seleccion = $("select").find("#specials");
$(seleccion).closest("['submit']");

//parte5
$("#slideshow").children().first().addClass("current").siblings().addClass("disabled");


//Ejercicio3

//parte1
var variable = 5;
contador2= 8;
for(contador = 0; contador < variable; contador++)
{
	var nuevalista = $("<li>List item "+contador2+"</li>");
	$("#myList").append(nuevalista)
	contador2++;
}

//parte2
$("#myList").find("li:even").remove();

//parte3
var ultimomodulo = $(".module").last();
$(ultimomodulo).append("<h2>H2</h2>");
$(ultimomodulo).append("<p>Parrafo</p>");


//parte4
var nuevooption = $('<option value=wednesday>Wednesday</option>');
$("select").append(nuevooption);

//parte5
var ultimomodulo2 = $(".module").last();
var caja = $('<div class="module" id="nuevo"><h2>Nuevo</h2><img src="images/fruit.jpg" alt="fruit" /></div>');
$(ultimomodulo2).after(caja);

//Ejercicio4

//parte1
var valorinput = $("input").first();
var valorlabel = $("label").text();
$(valorinput).attr("placeholder", valorlabel);

//parte2
var insertar = $(valorinput).addClass("hint");

//parte3 
$("label").remove();

//parte4
var placegris = $(valorinput).attr("placeholder");
    $(valorinput).on("focus", function(){
	$(valorinput).data("var", placegris);
	$(valorinput).removeClass("hint").removeAttr("placeholder");
});

//parte5
$(valorinput).on("blur", function()
{
	$(valorinput).addClass("hint").attr("placeholder", placegris);
});

//Ejercicio5

//parte1
$("div").find(".module").hide();

//parte2
var primermodulo = $("div").find(".module").first();
    var nuevoul = $("<ul></ul>");
    $(nuevoul).insertBefore(primermodulo);

//parte3
$("div").find(".module").each(function(){
var h2primero = $(this).find("h2").first().text();
var nuevoli = $("<li></li>").text(h2primero);
$(nuevoli).appendTo(nuevoul);
});

//parte4
$(nuevoul).find("li").on("click", function()
{
	var identificador = $(this).text().toLowerCase();
    var identificador2 = $(this).siblings().text().toLowerCase();
	var completo = "#" + identificador;
	$(completo).css("display", "block");
	$(completo).addClass("current");
	var completo2 = "#" + identificador2;
	$(completo2).css("display", "none");
	$(completo2).removeClass("current");
});

//Ejercicio6
$("#blog").find("p").hide();
$("#blog").find("h3").click(function()
{
	$("#blog").find("p").slideUp();
	$(this).parent().find("p").slideDown();
});

//Ejercicio7
var primerul = $("ul").first();
$(primerul).find("li").mouseover(function()
{
	$(this).find("ul").slideDown();
}).mouseout(function()
{
	$(this).find("ul").slideUp();
});

//Ejercicio8
var cambiar= $("div").first();
$("#slideshow").insertBefore(cambiar);

$("#slideshow").find("li").hide();
var losli = $("#slideshow").find("li");

var imagenesslide = $("#slideshow").find("img");

var todocompleto = $("<p>Hay "+imagenesslide.length+" imagenes</p>");
$(todocompleto).appendTo("#slideshow");
var todocompleto = $("<input value=''/>");
$(todocompleto).attr("readonly", "yes");
$(todocompleto).appendTo("#slideshow");

var contador = 0;
var tiempo = function(contador1)
{
	var mostrar = losli[contador1];
	$(losli).hide();
	$(mostrar).show();

	if(contador1 < 2)
	{
		contador1++;
	}
	else
	{
		contador1 = 0;
	}

	var total = $(mostrar).find("img").attr("alt");
	if(total != undefined)
	{
		$("input").first().attr("value", total);
	}
	else
	{
		$("input").first().attr("value", "No esta disponible");
	}

	setTimeout(tiempo, 2000, contador1);
};
tiempo(contador);
});